import asyncio
from collections.abc import Generator
from datetime import date, timedelta

import pytest
from httpx import ASGITransport, AsyncClient, Response
from sqlalchemy import delete

from app.db.database import SessionLocal
from app.db.models.activity import Activity
from app.db.models.goal import Goal
from app.db.models.user import User
from app.main import app
from app.services.auth import create_access_token, hash_password
from app.services.daily_score_v2 import calculate_daily_score_v2


EMAILS = ("insights-a@example.com", "insights-b@example.com")
TARGETS = {"steps": 10_000.0, "active_minutes": 60.0, "calories": 450.0}


async def _get(path: str, token: str) -> Response:
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        return await client.get(path, headers={"Authorization": f"Bearer {token}"})


@pytest.fixture(autouse=True)
def clean_users() -> Generator[None, None, None]:
    def clean() -> None:
        with SessionLocal() as session:
            session.execute(delete(User).where(User.email.in_(EMAILS)))
            session.commit()

    clean()
    yield
    clean()


def _user(email: str, with_goals: bool = False) -> tuple[User, str]:
    with SessionLocal() as session:
        user = User(email=email, password_hash=hash_password("password123"))
        session.add(user)
        session.flush()
        if with_goals:
            session.add_all(
                Goal(user_id=user.id, type=metric, target_value=target)
                for metric, target in TARGETS.items()
            )
        session.commit()
        session.refresh(user)
        session.expunge(user)
    return user, create_access_token(user.id)


def _activity(
    user: User,
    day: date,
    *,
    steps: float,
    score: float,
    active_minutes: float = 0,
    calories: float = 0,
) -> None:
    with SessionLocal() as session:
        session.add(
            Activity(
                user_id=user.id,
                date=day,
                steps=steps,
                active_minutes=active_minutes,
                distance=0,
                calories=calories,
                daily_score=score,
                score_version="v2",
                source="manual",
            )
        )
        session.commit()


def test_score_explanation_matches_server_formula() -> None:
    user, token = _user(EMAILS[0], with_goals=True)
    score = calculate_daily_score_v2(
        steps=5000,
        active_minutes=30,
        calories=225,
        goal_targets=TARGETS,
    )
    _activity(
        user,
        date.today(),
        steps=5000,
        active_minutes=30,
        calories=225,
        score=score,
    )

    response = asyncio.run(_get("/activity/today/score-explanation", token))
    payload = response.json()

    assert response.status_code == 200
    assert payload["available"] is True
    assert payload["score"] == 50
    assert [item["metric"] for item in payload["components"]] == [
        "steps",
        "active_minutes",
        "calories",
    ]
    assert sum(item["points"] for item in payload["components"]) == 50
    assert [item["weight"] for item in payload["components"]] == [0.5, 0.3, 0.2]


def test_stale_score_returns_honest_unavailable_explanation() -> None:
    user, token = _user(EMAILS[0], with_goals=True)
    _activity(user, date.today(), steps=5000, score=99)

    payload = asyncio.run(
        _get("/activity/today/score-explanation", token)
    ).json()

    assert payload["available"] is False
    assert payload["components"] == []
    assert "earlier goal settings" in payload["message"]


def test_insights_compare_recorded_days_and_find_strongest_day() -> None:
    user, token = _user(EMAILS[0])
    today = date.today()
    _activity(user, today - timedelta(days=9), steps=1000, score=30)
    _activity(user, today - timedelta(days=8), steps=1000, score=40)
    _activity(user, today - timedelta(days=2), steps=1000, score=50)
    _activity(user, today, steps=3000, score=70)

    payload = asyncio.run(_get("/activity/insights?days=7", token)).json()

    assert payload["current_recorded_days"] == 2
    assert payload["previous_recorded_days"] == 2
    assert payload["steps_change_percent"] == 100
    assert payload["average_score_change"] == 25
    assert payload["strongest_day"] == {
        "date": today.isoformat(),
        "daily_score": 70,
        "steps": 3000,
    }


def test_missing_days_are_not_averaged_as_zero() -> None:
    user, token = _user(EMAILS[0])
    today = date.today()
    _activity(user, today - timedelta(days=8), steps=1000, score=20)
    _activity(user, today, steps=1000, score=20)

    payload = asyncio.run(_get("/activity/insights?days=7", token)).json()

    assert payload["steps_change_percent"] == 0
    assert payload["average_score_change"] == 0
    assert payload["current_recorded_days"] == 1
    assert payload["previous_recorded_days"] == 1


def test_insights_report_insufficient_comparison_data() -> None:
    user, token = _user(EMAILS[0])
    _activity(user, date.today(), steps=1000, score=20)

    payload = asyncio.run(_get("/activity/insights?days=7", token)).json()

    assert payload["steps_change_percent"] is None
    assert payload["average_score_change"] is None
    assert payload["previous_recorded_days"] == 0


def test_insights_are_isolated_by_authenticated_user() -> None:
    user_a, token_a = _user(EMAILS[0])
    user_b, _ = _user(EMAILS[1])
    today = date.today()
    _activity(user_a, today, steps=100, score=10)
    _activity(user_b, today, steps=99999, score=100)

    payload = asyncio.run(_get("/activity/insights?days=7", token_a)).json()

    assert payload["current_recorded_days"] == 1
    assert payload["strongest_day"]["steps"] == 100
