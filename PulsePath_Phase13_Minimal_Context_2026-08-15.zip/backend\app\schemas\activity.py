from datetime import date

from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator


ActivityMetric = Annotated[float, Field(strict=True, ge=0, allow_inf_nan=False)]


class ActivityUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    steps: ActivityMetric | None = None
    active_minutes: ActivityMetric | None = None
    calories: ActivityMetric | None = None
    distance: ActivityMetric | None = None

    @field_validator("steps", "active_minutes", "calories", "distance")
    @classmethod
    def supplied_metrics_cannot_be_null(cls, value: float | None) -> float:
        if value is None:
            raise ValueError("activity metrics cannot be null")
        return value


class ActivityResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    date: date
    steps: float
    active_minutes: float
    distance: float
    calories: float
    daily_score: float
    score_version: str
    source: str


class ActivityHistoryResponse(ActivityResponse):
    """A recorded day; absent dates are intentionally omitted."""


class ScoreComponentResponse(BaseModel):
    metric: str
    value: float
    target: float | None
    progress: float
    weight: float
    points: float


class DailyScoreExplanationResponse(BaseModel):
    score: float
    score_version: str
    available: bool
    message: str | None = None
    components: list[ScoreComponentResponse]


class StrongestDayResponse(BaseModel):
    date: date
    daily_score: float
    steps: float


class ActivityInsightsResponse(BaseModel):
    days: int
    current_recorded_days: int
    previous_recorded_days: int
    steps_change_percent: float | None
    average_score_change: float | None
    strongest_day: StrongestDayResponse | None
