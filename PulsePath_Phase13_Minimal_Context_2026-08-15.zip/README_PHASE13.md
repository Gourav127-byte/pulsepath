# PulsePath Phase 13 minimal context handoff

## Purpose and boundary

This archive is a context-only subset of the current PulsePath repository for
Phase 13: **Activity Recovery + Quick Log**. Phase 12 and its Redmi 8 physical
verification are complete and passing. The repository remains the source of
truth; inspect the current repository before editing.

**Modify only files required for Phase 13. Context files should remain unchanged
unless modification is genuinely required and justified. If required project
context is missing, stop and report instead of inventing architecture.**

Do not start Phase 14 and do not add workout, timer, nutrition, or social
features. Avoid schema, authentication, Health Connect, history, and cache
redesigns unless a confirmed requirement cannot be met safely without one; in
that case stop and report.

## Current end-to-end activity path

Flutter Today UI
-> Riverpod providers
-> `TodayActivityRepository`
-> shared authenticated `ApiClient`
-> FastAPI activity router
-> `get_current_user`
-> SQLAlchemy `Activity`/`Goal`
-> PostgreSQL.

`ApiClient` reads the JWT from secure storage and sends
`Authorization: Bearer <token>`. Backend activity queries and writes are scoped
to `current_user.id`. `activities` has a unique `(user_id, date)` constraint and
an `ON DELETE CASCADE` foreign key to `users.id`.

## Existing behavior that Phase 13 must handle carefully

1. `GET /activity/today` currently lazily creates a zero-valued Activity row if
   no row exists for the backend's local calendar date. This means the current
   API can turn a missing day into a recorded zero day. Phase 13 explicitly
   requires missing data to remain distinguishable from a real zero, so inspect
   this behavior before designing recovery. Do not silently redefine old rows.
2. `PATCH /activity/today` is partial. Omitted fields remain unchanged. Supplied
   fields replace their stored values; they are not added as deltas.
3. The existing manual editor captures a snapshot through its `activity`
   argument when opened, pre-fills all four metrics, compares submitted values
   against that snapshot, and PATCHes only changed fields.
4. Health Connect reads today's aggregate Steps, Distance Delta, and
   `ACTIVE_ENERGY_BURNED`. Distance is converted from metres to kilometres.
   Active Minutes is intentionally unsupported.
5. Health sync sends only non-null metrics. It treats Health Connect readings as
   authoritative daily totals and replaces those fields through PATCH. It does
   not add them to manual values. Empty/unavailable/permission-error reads do
   not PATCH.
6. The current Activity row has a single `source` string, but the PATCH route
   does not update it. The schema does not preserve per-metric provenance.
   Therefore mixed manual/Health data semantics cannot safely be inferred from
   `source` alone. Do not invent provenance.
7. A successful activity PATCH recomputes Daily Score v2 server-side from the
   complete resulting row and the authenticated user's current goal targets:
   50% Steps, 30% Active Minutes, 20% Active Calories. Missing required goals
   contribute zero. Distance does not contribute. Flutter must not recalculate.
8. The temporary demo cache is a read-only fallback after failed GETs. Writes
   still require the backend and must not optimistically mutate cached data.
9. Journey/history uses only actual Activity rows. Missing dates are omitted;
   stored zero rows are genuine recorded zeros. History and insights are
   authenticated and user-scoped.
10. Current date policy is backend `date.today()` plus device local-day Health
    reads. Per-user timezone redesign remains deferred.

## Phase 12 physical baseline

- Redmi 8: login, authenticated Today, score explanation, Journey 7/30 ranges,
  metric switching, recorded-zero behavior, and insufficient-insight state all
  passed.
- Score explanation is backend-owned and the small-screen sheet scrolls without
  overflow.
- Final validation before this handoff: backend 97 passed; Flutter 111 passed;
  analyzer clean; Alembic head `0004_domain_user_fks`.
- The Uvicorn development server on port 8000 was restarted with current code
  after a stale process initially returned 404 for Phase 12 endpoints.

## Included groups

### Flutter activity implementation (primary modification candidates)

- `lib/features/today/**`: Today models, UI, manual editor, repositories,
  providers, Health Connect service/sync, score explanation, and cards.
- `lib/core/activity/**`: metric definitions and legacy mock context.

### Flutter shared/context dependencies (normally context-only)

- `lib/core/network/**`: shared API client/base URL and authenticated request
  behavior.
- `lib/core/cache/temporary_demo_cache.dart`: read-only demo fallback semantics.
- `lib/core/theme/pulse_path_theme.dart`: Today widget styling dependency.
- Selected `auth`, `goals`, and `profile` model/repository/provider files needed
  by ApiClient and Today imports. Do not change these merely because included.
- `lib/features/journey/**`: history, missing-day semantics, insights, providers,
  and Journey UI context.
- `pubspec.yaml`, `pubspec.lock`, and `analysis_options.yaml`: dependency and
  analyzer context.
- Android main/debug manifests and debug network-security XML: Health Connect,
  INTERNET, and development-LAN permission context. Cleartext remains
  debug-only.

### Backend activity implementation (primary modification candidates)

- Activity route/schema/model and Daily Score/insight services.
- Goal and User models because activity scoring and ownership depend on them.
- Auth dependency/service, DB/session/config, and app router context.
- Alembic history because the current Activity uniqueness/FK ownership contract
  must be understood; no migration is implied by inclusion.

### Tests

- Flutter activity write/network, Health sync, cache, auth-header, Journey, and
  main Today regression tests.
- Backend Phase 7A activity-write, Phase 11 history, Phase 12 insight, Phase 9D
  ownership, and isolated PostgreSQL fixture tests.

## Validation commands for a full repository checkout

From repository root:

```powershell
flutter test --no-pub
flutter analyze --no-pub
```

From `backend/`:

```powershell
.\venv\Scripts\python.exe -m pytest
.\venv\Scripts\alembic.exe current
.\venv\Scripts\alembic.exe heads
```

Backend tests must use the isolated PostgreSQL test database enforced by
`backend/tests/conftest.py`; never point tests at the development database.

## Deliberately excluded

`.env`, secrets, credentials, `.git`, virtual environments, `.dart_tool`, build
outputs, caches, generated binaries, media/audio/branding assets, promo files,
IDE metadata, diagnostic artifacts, and unrelated auth/profile/goals screens or
backend password-reset/profile routes.

This subset is for review and patch planning, not a standalone runnable Flutter
project. Apply approved changes to the full current repository, not directly to
this archive.
