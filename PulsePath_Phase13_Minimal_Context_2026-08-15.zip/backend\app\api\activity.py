from datetime import date, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.api.dependencies import get_current_user
from app.db.database import get_db
from app.db.models.activity import Activity
from app.db.models.goal import Goal
from app.db.models.user import User
from app.schemas.activity import (
    ActivityHistoryResponse,
    ActivityInsightsResponse,
    ActivityResponse,
    ActivityUpdate,
    DailyScoreExplanationResponse,
)
from app.services.activity_insights import build_activity_insights
from app.services.daily_score import (
    SCORE_VERSION as V1_SCORE_VERSION,
    calculate_daily_score,
    explain_daily_score,
)
from app.services.daily_score_v2 import (
    SCORE_VERSION,
    calculate_daily_score_v2,
    explain_daily_score_v2,
)

router = APIRouter(prefix="/activity", tags=["activity"])


def _validated_days(days: int) -> int:
    if days not in (7, 30):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="days must be either 7 or 30",
        )
    return days


@router.get("/history", response_model=list[ActivityHistoryResponse])
def get_activity_history(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
    days: Annotated[int, Query()] = 7,
) -> list[Activity]:
    _validated_days(days)

    # PulsePath currently uses the backend's local calendar date consistently.
    # Per-user timezones require a future explicit product/schema decision.
    end_date = date.today()
    start_date = end_date - timedelta(days=days - 1)
    return list(
        db.scalars(
            select(Activity)
            .where(
                Activity.user_id == user.id,
                Activity.date >= start_date,
                Activity.date <= end_date,
            )
            .order_by(Activity.date.asc())
        ).all()
    )


@router.get("/insights", response_model=ActivityInsightsResponse)
def get_activity_insights(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
    days: Annotated[int, Query()] = 7,
) -> dict[str, object]:
    _validated_days(days)
    end_date = date.today()
    current_start = end_date - timedelta(days=days - 1)
    previous_start = current_start - timedelta(days=days)
    records = list(
        db.scalars(
            select(Activity)
            .where(
                Activity.user_id == user.id,
                Activity.date >= previous_start,
                Activity.date <= end_date,
            )
            .order_by(Activity.date.asc())
        ).all()
    )
    current = [record for record in records if record.date >= current_start]
    previous = [record for record in records if record.date < current_start]
    insights = build_activity_insights(current, previous)
    strongest = insights.pop("strongest_day")
    return {
        "days": days,
        **insights,
        "strongest_day": (
            {
                "date": strongest.date,
                "daily_score": strongest.daily_score,
                "steps": strongest.steps,
            }
            if isinstance(strongest, Activity)
            else None
        ),
    }


@router.get(
    "/today/score-explanation",
    response_model=DailyScoreExplanationResponse,
)
def get_today_score_explanation(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> dict[str, object]:
    activity = db.scalar(
        select(Activity).where(
            Activity.user_id == user.id,
            Activity.date == date.today(),
        )
    )
    if activity is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Today's activity was not found",
        )

    if activity.score_version == V1_SCORE_VERSION:
        components = explain_daily_score(
            steps=activity.steps,
            active_minutes=activity.active_minutes,
            calories=activity.calories,
        )
        calculated = calculate_daily_score(
            steps=activity.steps,
            active_minutes=activity.active_minutes,
            calories=activity.calories,
        )
    elif activity.score_version == SCORE_VERSION:
        goals = db.scalars(
            select(Goal).where(
                Goal.user_id == user.id,
                Goal.type.in_(("steps", "active_minutes", "calories")),
            )
        ).all()
        targets = {goal.type: goal.target_value for goal in goals}
        components = explain_daily_score_v2(
            steps=activity.steps,
            active_minutes=activity.active_minutes,
            calories=activity.calories,
            goal_targets=targets,
        )
        calculated = calculate_daily_score_v2(
            steps=activity.steps,
            active_minutes=activity.active_minutes,
            calories=activity.calories,
            goal_targets=targets,
        )
    else:
        return {
            "score": activity.daily_score,
            "score_version": activity.score_version,
            "available": False,
            "message": "This score version cannot be explained yet.",
            "components": [],
        }

    available = calculated == activity.daily_score
    return {
        "score": activity.daily_score,
        "score_version": activity.score_version,
        "available": available,
        "message": (
            None
            if available
            else "This score used earlier goal settings, so its exact breakdown is unavailable."
        ),
        "components": components if available else [],
    }


@router.get("/today", response_model=ActivityResponse)
def get_today_activity(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> Activity:
    today = date.today()
    activity = db.scalar(
        select(Activity).where(
            Activity.user_id == user.id,
            Activity.date == today,
        )
    )

    if activity is None:
        # Lazily initialize today's activity for the user
        activity = Activity(
            user_id=user.id,
            date=today,
            steps=0,
            active_minutes=0,
            calories=0,
            distance=0,
            daily_score=0,
            score_version=SCORE_VERSION,
            source="system",
        )
        db.add(activity)
        try:
            db.commit()
            db.refresh(activity)
        except SQLAlchemyError as error:
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Could not initialize today's activity",
            ) from error

    return activity


@router.patch("/today", response_model=ActivityResponse)
def update_today_activity(
    update: ActivityUpdate,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> Activity:
    activity = db.scalar(
        select(Activity).where(
            Activity.user_id == user.id,
            Activity.date == date.today(),
        )
    )
    if activity is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Today's activity was not found",
        )

    try:
        for field, value in update.model_dump(exclude_unset=True).items():
            setattr(activity, field, value)

        goals = db.scalars(
            select(Goal).where(
                Goal.user_id == user.id,
                Goal.type.in_(("steps", "active_minutes", "calories")),
            )
        ).all()
        goal_targets = {goal.type: goal.target_value for goal in goals}
        activity.daily_score = calculate_daily_score_v2(
            steps=activity.steps,
            active_minutes=activity.active_minutes,
            calories=activity.calories,
            goal_targets=goal_targets,
        )
        activity.score_version = SCORE_VERSION

        db.commit()
        db.refresh(activity)
    except SQLAlchemyError as error:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not update today's activity",
        ) from error
    except Exception as error:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Could not update today's activity",
        ) from error

    return activity
