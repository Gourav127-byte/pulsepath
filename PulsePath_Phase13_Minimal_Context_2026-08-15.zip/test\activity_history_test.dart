import 'dart:convert';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:pulsepath/core/network/api_client.dart';
import 'package:pulsepath/features/journey/data/activity_history_repository.dart';
import 'package:pulsepath/features/journey/models/activity_history_entry.dart';
import 'package:pulsepath/features/journey/models/activity_insights.dart';
import 'package:pulsepath/features/journey/presentation/journey_screen.dart';
import 'package:pulsepath/features/journey/providers/activity_history_provider.dart';

const _historyJson = <Map<String, dynamic>>[
  {
    'date': '2026-08-12',
    'steps': 12450.0,
    'active_minutes': 63.0,
    'distance': 8.4,
    'calories': 510.0,
    'daily_score': 100.0,
    'score_version': 'v2',
    'source': 'health_connect',
  },
];

void main() {
  test('history parses trustworthy backend fields', () {
    final entry = ActivityHistoryEntry.fromJson(_historyJson.single);
    expect(entry.date, DateTime(2026, 8, 12));
    expect(entry.steps, 12450);
    expect(entry.distance, 8.4);
    expect(entry.activeCalories, 510);
    expect(entry.dailyScore, 100);
    expect(entry.scoreVersion, 'v2');
  });

  test('repository sends bounded authenticated history request', () async {
    late http.Request request;
    final repository = ActivityHistoryRepository(
      ApiClient(
        baseUrl: 'https://example.test',
        client: MockClient((value) async {
          request = value;
          return http.Response(jsonEncode(_historyJson), 200);
        }),
        authTokenProvider: () async => 'token',
      ),
    );

    final history = await repository.fetchHistory(days: 7);

    expect(request.url.path, '/activity/history');
    expect(request.url.queryParameters, {'days': '7'});
    expect(request.headers['Authorization'], 'Bearer token');
    expect(history.single.steps, 12450);
  });

  test('insights parse backend-owned comparisons and strongest day', () {
    final insights = ActivityInsights.fromJson({
      'days': 7,
      'current_recorded_days': 2,
      'previous_recorded_days': 2,
      'steps_change_percent': 25.0,
      'average_score_change': 5.0,
      'strongest_day': {
        'date': '2026-08-12',
        'daily_score': 91.0,
        'steps': 12450.0,
      },
    });

    expect(insights.stepsChangePercent, 25);
    expect(insights.averageScoreChange, 5);
    expect(insights.strongestDay?.date, DateTime(2026, 8, 12));
    expect(insights.strongestDay?.steps, 12450);
  });

  testWidgets('Journey renders real values and switches metrics', (
    tester,
  ) async {
    await tester.pumpWidget(_appWithHistory(_entries()));
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('history_chart')), findsOneWidget);
    expect(find.text('1 of 7 days have recorded data'), findsOneWidget);
    expect(find.text('No activity recorded yet.'), findsNothing);

    final chartRect = tester.getRect(find.byKey(const Key('history_chart')));
    await tester.tapAt(Offset(chartRect.right - 4, chartRect.center.dy));
    await tester.pump();
    expect(find.textContaining('12450 steps'), findsOneWidget);

    await tester.tap(find.byKey(const Key('history_metric_distance')));
    await tester.pump();
    expect(
      tester
          .widget<ChoiceChip>(find.byKey(const Key('history_metric_distance')))
          .selected,
      isTrue,
    );
  });

  testWidgets('Journey shows loading, no-history, and network error states', (
    tester,
  ) async {
    final pending = Completer<List<ActivityHistoryEntry>>();
    tester.view.physicalSize = const Size(600, 1200);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      ProviderScope(
        key: UniqueKey(),
        overrides: [
          activityHistoryProvider.overrideWith((ref, days) => pending.future),
          activityInsightsProvider.overrideWith(
            (ref, days) async => _emptyInsights(days),
          ),
        ],
        child: const MaterialApp(home: Scaffold(body: JourneyScreen())),
      ),
    );
    await tester.pump();
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    await tester.pumpWidget(_appWithHistory(const []));
    await tester.pumpAndSettle();
    expect(find.text('No activity recorded yet.'), findsOneWidget);

    await tester.pumpWidget(
      ProviderScope(
        key: UniqueKey(),
        overrides: [
          activityHistoryProvider.overrideWith(
            (ref, days) => Future.error(const NetworkException('offline')),
          ),
          activityInsightsProvider.overrideWith(
            (ref, days) async => _emptyInsights(days),
          ),
        ],
        child: const MaterialApp(home: Scaffold(body: JourneyScreen())),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Could not load activity history.'), findsOneWidget);
    expect(find.text('Retry'), findsOneWidget);
  });

  testWidgets('Journey renders deterministic recorded-day insights', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(600, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      _appWithHistory(
        _entries(),
        insights: ActivityInsights(
          days: 7,
          currentRecordedDays: 2,
          previousRecordedDays: 2,
          stepsChangePercent: 25,
          averageScoreChange: -3,
          strongestDay: StrongestActivityDay(
            date: DateTime(2026, 8, 12),
            dailyScore: 91,
            steps: 12450,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
      find.byKey(const Key('progress_insights')),
      300,
    );

    expect(
      find.text(
        'Steps per recorded day increased 25.0% versus the previous 7 days.',
      ),
      findsOneWidget,
    );
    expect(
      find.text('Average Daily Score declined by 3.0 points.'),
      findsOneWidget,
    );
    expect(find.textContaining('Strongest recorded day'), findsOneWidget);
    expect(find.text('Calculated from recorded days only.'), findsOneWidget);
  });

  testWidgets('Journey reports insufficient comparison data honestly', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(600, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      _appWithHistory(
        _entries(),
        insights: ActivityInsights(
          days: 7,
          currentRecordedDays: 1,
          previousRecordedDays: 0,
          stepsChangePercent: null,
          averageScoreChange: null,
          strongestDay: StrongestActivityDay(
            date: DateTime(2026, 8, 12),
            dailyScore: 91,
            steps: 12450,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
      find.byKey(const Key('progress_insights')),
      300,
    );

    expect(
      find.text('Not enough data yet for period comparisons.'),
      findsOneWidget,
    );
  });
}

Widget _appWithHistory(
  List<ActivityHistoryEntry> entries, {
  ActivityInsights? insights,
}) {
  return ProviderScope(
    key: UniqueKey(),
    overrides: [
      activityHistoryProvider.overrideWith((ref, days) async => entries),
      activityInsightsProvider.overrideWith(
        (ref, days) async => insights ?? _emptyInsights(days),
      ),
    ],
    child: const MaterialApp(home: Scaffold(body: JourneyScreen())),
  );
}

ActivityInsights _emptyInsights(int days) {
  return ActivityInsights(
    days: days,
    currentRecordedDays: 0,
    previousRecordedDays: 0,
    stepsChangePercent: null,
    averageScoreChange: null,
    strongestDay: null,
  );
}

List<ActivityHistoryEntry> _entries() {
  return [
    ActivityHistoryEntry(
      date: DateUtils.dateOnly(DateTime.now()),
      steps: 12450,
      activeMinutes: 63,
      distance: 8.4,
      activeCalories: 510,
      dailyScore: 100,
      scoreVersion: 'v2',
      source: 'health_connect',
    ),
  ];
}
