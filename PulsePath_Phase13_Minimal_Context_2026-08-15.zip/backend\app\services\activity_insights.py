from collections.abc import Sequence
from statistics import fmean

from app.db.models.activity import Activity


def _average(records: Sequence[Activity], field: str) -> float | None:
    if not records:
        return None
    return float(fmean(float(getattr(record, field)) for record in records))


def _percent_change(current: float | None, previous: float | None) -> float | None:
    if current is None or previous is None or previous == 0:
        return None
    return ((current - previous) / previous) * 100


def build_activity_insights(
    current: Sequence[Activity], previous: Sequence[Activity]
) -> dict[str, object]:
    current_steps = _average(current, "steps")
    previous_steps = _average(previous, "steps")
    current_score = _average(current, "daily_score")
    previous_score = _average(previous, "daily_score")
    strongest = (
        max(current, key=lambda item: (item.daily_score, item.steps, item.date))
        if current
        else None
    )
    return {
        "current_recorded_days": len(current),
        "previous_recorded_days": len(previous),
        "steps_change_percent": _percent_change(current_steps, previous_steps),
        "average_score_change": (
            current_score - previous_score
            if current_score is not None and previous_score is not None
            else None
        ),
        "strongest_day": strongest,
    }
