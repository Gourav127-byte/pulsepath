class StrongestActivityDay {
  const StrongestActivityDay({
    required this.date,
    required this.dailyScore,
    required this.steps,
  });

  factory StrongestActivityDay.fromJson(Map<String, dynamic> json) {
    return StrongestActivityDay(
      date: DateTime.parse(json['date'] as String),
      dailyScore: (json['daily_score'] as num).toDouble(),
      steps: (json['steps'] as num).toDouble(),
    );
  }

  final DateTime date;
  final double dailyScore;
  final double steps;
}

class ActivityInsights {
  const ActivityInsights({
    required this.days,
    required this.currentRecordedDays,
    required this.previousRecordedDays,
    required this.stepsChangePercent,
    required this.averageScoreChange,
    required this.strongestDay,
  });

  factory ActivityInsights.fromJson(Map<String, dynamic> json) {
    final strongest = json['strongest_day'];
    return ActivityInsights(
      days: json['days'] as int,
      currentRecordedDays: json['current_recorded_days'] as int,
      previousRecordedDays: json['previous_recorded_days'] as int,
      stepsChangePercent: (json['steps_change_percent'] as num?)?.toDouble(),
      averageScoreChange: (json['average_score_change'] as num?)?.toDouble(),
      strongestDay: strongest is Map<String, dynamic>
          ? StrongestActivityDay.fromJson(strongest)
          : null,
    );
  }

  final int days;
  final int currentRecordedDays;
  final int previousRecordedDays;
  final double? stepsChangePercent;
  final double? averageScoreChange;
  final StrongestActivityDay? strongestDay;

  bool get hasComparablePeriods =>
      currentRecordedDays > 0 && previousRecordedDays > 0;
}
