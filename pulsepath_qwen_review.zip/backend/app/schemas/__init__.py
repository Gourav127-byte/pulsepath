"""API response schemas."""
