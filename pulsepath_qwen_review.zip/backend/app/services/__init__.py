"""Reusable application services."""
